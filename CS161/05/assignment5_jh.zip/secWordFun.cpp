#include <iostream>
#include <string>
using namespace std;

void validWord(string& guess1); 
int main()
{
    string player1Guess;
    string answer = "foo";
    int attempts = 5;

    cout << "Player1: " << endl;
    cout << "Please enter a string for secret word ";
    //cin >> player1Guess;
    getline (cin, player1Guess);
    validWord(player1Guess);

    while(attempts > 0)
    {
        // syntax to compare strings
        if (player1Guess.compare(answer) != 0)
        {
            cout << "string is incorrect" << endl;
            attempts--;
            cout << attempts << endl;
            continue;
        }
        else
        {
            cout << "Congragulations" << endl;
            cout << attempts << endl;
        }

     return 0;

    }

    /*
     *Uses a loop to repeatedly do the following 
     *(you choose how many guesses allowed, perhaps related to word length):
     *i. Show the user what (if any) of the word has been correctly guessed so far,
     *(Note: perhaps using underscores or hyphens to denote letters not yet guessed)
     *ii. Asks the other user to guess a letter in the secret word,
     */

    /*
     * iii. Checks if the guess is a valid letter (best to use a function to keep the code in smaller sections)
     * iv. Tells the user whether the letter is in the word (and if it was in it multiple times),
     * (Note: likely using an if statement and loop here somewhere...)
     */ 

    /*
     * iv. Tells the user whether the letter is in the word (and if it was in it multiple times),
     * (Note: likely using an if statement and loop here somewhere...)
     *
     * v. Changes the list of possible letters to reflect the user's newest guess,
     * (Note: this can be tricky, but remember that you can usually use multiple variables to track multiple aspects of related information!)
     */
}

void validWord(string& guess1)
{
    for (int i = 0; i < guess1.length(); i++) {
        //if (isdigit(guess1[0]))
        if (isdigit(guess1.at(i)))
        {
            // str.at(i);
            cout << "word must be a-z or A-Z";
        }
        else if (ispunct(guess1.at(i)))
        {
            cout << "word must be a-z or A-Z";
        }
        else if (isspace(guess1.at(i)))
        {
            cout << "word must be a-z or A-Z";
        }
    }
}
