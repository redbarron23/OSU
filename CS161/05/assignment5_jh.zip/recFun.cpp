#include <iostream>
using namespace std;

int fibo(const int& n);

int main()
{
    int firstNum = 11;
    //fibo(first);
    cout << fibo(firstNum);
    return 0;
}

// borrowed this from stakoverflow
// http://stackoverflow.com/questions/1518726/recursive-fibonacci
// curious how the stack keeps track
int fibo(const int& n)
{
    if (n == 0)
    {
        return 0;
    }    

    if ( n == 1)
    {
         return 1; 
    }
    return fibo(n - 1) + fibo(n - 2);
}
